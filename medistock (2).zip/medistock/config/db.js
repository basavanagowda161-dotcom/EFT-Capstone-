const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');

const db = new DatabaseSync('database/medistock.db');
db.exec(fs.readFileSync('database/schema.sql', 'utf8'));

// Columns added later. If they already exist, the error is ignored.
try { db.exec('ALTER TABLE schedules ADD COLUMN doctor TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE schedules ADD COLUMN hospital TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE sales ADD COLUMN order_id INTEGER'); } catch (e) {}

// Online orders with the delivery address
db.exec(
  'CREATE TABLE IF NOT EXISTS orders (' +
  'id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, name TEXT, phone TEXT, ' +
  'address TEXT, city TEXT, pincode TEXT, total REAL, status TEXT DEFAULT \'Placed\', ' +
  'created_at TEXT DEFAULT (datetime(\'now\',\'localtime\')))'
);

module.exports = db;